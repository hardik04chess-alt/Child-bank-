// Local storage keys
const USERS_KEY = 'cb_users';
const TX_KEY = 'cb_transactions';
const REWARDS_KEY = 'cb_rewards';

let users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
let transactions = JSON.parse(localStorage.getItem(TX_KEY) || '[]');
let rewards = JSON.parse(localStorage.getItem(REWARDS_KEY) || '[]'); // Starts empty
let currentUser = null;

function showTab(tab) {
  document.querySelectorAll('#points, #rewards, #admin, #login-screen').forEach(el => el.classList.add('hidden'));
  document.getElementById(tab).classList.remove('hidden');
  document.querySelectorAll('nav a').forEach(a => a.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
}

function login() {
  const email = document.getElementById('email').value.trim().toLowerCase();
  const pass = document.getElementById('password').value;
  if (users[email] && users[email].pass === pass) {
    currentUser = email;
    loadUserData();
    showTab('points');
  } else {
    alert("Wrong email or password!");
  }
}

function register() {
  const email = prompt("Enter child's email:").trim().toLowerCase();
  const pass = prompt("Set a password for this child:");
  if (email && pass) {
    users[email] = { pass, points: 0 };
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    alert("Child registered successfully! Now login.");
  }
}

function logout() {
  currentUser = null;
  showTab('login-screen');
  document.getElementById('email').value = '';
  document.getElementById('password').value = '';
}

function loadUserData() {
  const points = users[currentUser]?.points || 0;
  document.getElementById('balance').innerText = points;

  const table = document.getElementById('history-table');
  table.innerHTML = "<tr><th>Date</th><th>Points</th><th>Reason</th></tr>";
  transactions
    .filter(t => t.email === currentUser)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 20)
    .forEach(t => {
      const sign = t.amount > 0 ? '+' : '';
      table.innerHTML += `<tr><td>${new Date(t.date).toLocaleDateString()}</td><td>${sign}${t.amount}</td><td>${t.reason}</td></tr>`;
    });

  loadRewards();
}

function loadRewards() {
  const list = document.getElementById('rewards-list');
  list.innerHTML = rewards.length === 0 
    ? '<div class="empty">No rewards yet!<br>Admin will add them soon ✨</div>'
    : '';
  
  const userPoints = users[currentUser]?.points || 0;
  rewards.forEach(r => {
    const canRedeem = userPoints >= r.cost;
    list.innerHTML += `
      <div class="reward">
        <h3>${r.name}</h3>
        <p>Cost: ${r.cost} ⭐</p>
        <button ${!canRedeem ? 'disabled style="background:gray; cursor:not-allowed;"' : ''} 
          onclick="redeemReward('${r.name}', ${r.cost})">
          ${canRedeem ? 'Redeem Now!' : 'Not Enough Points'}
        </button>
      </div>`;
  });
}

function redeemReward(name, cost) {
  if (confirm(`Redeem "${name}" for ${cost} points?`)) {
    users[currentUser].points -= cost;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    transactions.push({
      email: currentUser,
      amount: -cost,
      reason: `Redeemed: ${name}`,
      date: new Date()
    });
    localStorage.setItem(TX_KEY, JSON.stringify(transactions));
    loadUserData();
    alert("Yay! Reward redeemed! 🎉");
  }
}

function enterAdmin() {
  const pass = document.getElementById('admin-pass').value;
  if (pass === "hardikadmin") {
    document.getElementById('admin-panel').classList.remove('hidden');
    document.getElementById('admin-pass').value = '';
  } else {
    alert("Wrong admin password!");
  }
}

function addReward() {
  const name = document.getElementById('r-name').value.trim();
  const cost = parseInt(document.getElementById('r-cost').value);
  if (name && cost > 0) {
    rewards.push({ name, cost });
    localStorage.setItem(REWARDS_KEY, JSON.stringify(rewards));
    alert("Reward added successfully!");
    document.getElementById('r-name').value = '';
    document.getElementById('r-cost').value = '';
  } else {
    alert("Please enter valid reward name and points!");
  }
}

function givePoints() {
  const email = document.getElementById('user-email').value.trim().toLowerCase();
  const amount = parseInt(document.getElementById('points-amount').value);
  const reason = document.getElementById('reason').value.trim() || "Admin update";

  if (users[email] && !isNaN(amount)) {
    users[email].points += amount;
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    transactions.push({
      email,
      amount,
      reason,
      date: new Date()
    });
    localStorage.setItem(TX_KEY, JSON.stringify(transactions));
    alert(`Successfully gave ${amount > 0 ? '+' : ''}${amount} points to ${email}!`);
    document.getElementById('user-email').value = '';
    document.getElementById('points-amount').value = '';
    document.getElementById('reason').value = '';
  } else {
    alert("Child email not found or invalid amount!");
  }
}

// Start on login screen
showTab('login-screen');